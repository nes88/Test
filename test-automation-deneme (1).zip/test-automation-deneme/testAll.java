package ikas.TestNG;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.testng.ITestResult;
import org.testng.annotations.*;

import org.openqa.selenium.*;
        import org.openqa.selenium.interactions.Actions;
        import org.openqa.selenium.support.ui.ExpectedConditions;
        import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;

import org.testng.annotations.Test;
        import org.openqa.selenium.chrome.ChromeDriver;
        import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


import java.util.Date;
        import java.util.List;
        import java.util.Random;
        import java.util.concurrent.TimeUnit;

        import static org.openqa.selenium.By.name;
        import static org.openqa.selenium.By.xpath;


public class testAll   {

    public static ExtentHtmlReporter htmlReporter;
    public static ExtentReports extent;
    public static ExtentTest test;
    public WebDriver driver;
    public static String loginUrl = "https://app-dev.ikas.com/#/login";
    private String TagInnerText;
    public static String POSmenuUrl = "https://app-dev.ikas.com/pos/#/menu";
    public static String YonetimPaneliUrl = "https://app-dev.ikas.com/#/fetch?name";



    @BeforeTest
    public void setUp() {


        try {


            htmlReporter = new ExtentHtmlReporter("ExtentReport/Report.html");
            extent = new ExtentReports();
            extent.attachReporter(htmlReporter);


            htmlReporter.config().setChartVisibilityOnOpen(true);
            htmlReporter.config().setDocumentTitle("AutomationTesting.in Demo Report");
            htmlReporter.config().setReportName("My Own Report");
            htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
            htmlReporter.config().setTheme(Theme.DARK);


            DesiredCapabilities capabilities = DesiredCapabilities.chrome();
            System.setProperty("webdriver.chrome.driver", "Driver/chromedriver");
            driver = new ChromeDriver(capabilities);
            driver.manage().window().maximize();
            driver.manage().deleteAllCookies();


            //dynamic wait
            driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
            driver.manage().timeouts().setScriptTimeout(30, TimeUnit.SECONDS);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(priority = 1)
    public void Login() {

        try {


            test = extent.createTest("Login");
            driver.get(loginUrl);
            driver.findElement(name("email")).sendKeys("nesli.necipoglu+1@ikas.com");
            Thread.sleep(1000);
            driver.findElement(name("password")).sendKeys("123=ilsen");
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/div/div/div[2]/div/div[2]/form/div[3]/button")).click();
            Thread.sleep(5000);


        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    @Test(priority = 2)
    public void marketurunsatinal() {

        try {
            test = extent.createTest("Donanım Market Ürün Satın Al");
            //terminale git
            driver.findElement(xpath("/html/body/div[1]/div/div[2]/div/div/button")).click(); // yönetici
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/div/div[2]/div/ul/li[2]/a")).click(); //ayarlar
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div/a[3]")).click(); // lisanslar
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div/a[5]")).click(); // Donanım Market
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[2]/div[1]/div[1]/div[2]/div")).click(); //ürün satın al
            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]/div")).click(); // alışverişi tamamla
            Thread.sleep(5000);
            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]/div/div[3]/div/div[2]")).click(); //devam et

            Thread.sleep(5000);
            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]/div/div[2]/div[2]/div/div[2]/div/div[2]/div")).click(); //başka bir kart kullan
            Thread.sleep(2000);


            // Hatalı kart kodları

            //HATALI KART GİRİŞİ-1
            //kart numarası gir

            String hataliKartNumaralari[] = {"5406670000000009", "4111111111111129", "4129111111111111", "4151111111111112", "4127111111111113", "4126111111111114", "4125111111111115", "4124111111111116", "4123111111111117", "4130111111111118", "4121111111111119", "4120111111111110", "4130111111111118", "4131111111111117", "4141111111111115", "4128111111111112", "4111111111111129", "4151111111111393", "5406670000000009"};
            Random hatalikartrand = new Random();
            int num = hatalikartrand.nextInt(hataliKartNumaralari.length);

            String hataliKart = hataliKartNumaralari[num];

            System.out.println("Birinci Hatalı Kart Numarası= " + hataliKart);

            driver.findElement(xpath("//*[@id=\"credit_card_number\"]")).sendKeys(hataliKart);
            Thread.sleep(1000);

            //kart üzerindeki isim


            driver.findElement(xpath("//*[@id=\"card_holder\"]")).sendKeys("Ahmet Yıldırım");
            //son kullanma tarihi
            Thread.sleep(1000);

            driver.findElement(xpath("//*[@id=\"card_expire_date\"]")).sendKeys("0525");

            //cvv
            Thread.sleep(1000);
            driver.findElement(xpath("//*[@id=\"card_cvv\"]")).sendKeys("123");
            //ödemeyi tamamla
            Thread.sleep(3000);

            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]/div/div[3]/div/div[2]/div[2]/span")).click();  //ödemeyi tamamla

            //HATALI KART GİRİŞİ-2
            Thread.sleep(3000);
            driver.findElement(xpath("//*[@id=\"credit_card_number\"]")).clear();
            Thread.sleep(1000);

            String hataliKartNumaralari2[] = {"5406670000000009", "4111111111111129", "4129111111111111", "4151111111111112", "4127111111111113", "4126111111111114", "4125111111111115", "4124111111111116", "4123111111111117", "4130111111111118", "4121111111111119", "4120111111111110", "4130111111111118", "4131111111111117", "4141111111111115", "4128111111111112", "4111111111111129", "4151111111111393", "5406670000000009"};
            Random hatalikartrand2 = new Random();
            int number = hatalikartrand2.nextInt(hataliKartNumaralari2.length);

            String hataliKart2 = hataliKartNumaralari2[number];
            System.out.println("İkinci Hatalı Kart Numarası = " + hataliKart2);
            driver.findElement(xpath("//*[@id=\"credit_card_number\"]")).sendKeys(hataliKart2);
            Thread.sleep(3000);

            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]/div/div[3]/div/div[2]/div[2]/span")).click();  //ödemeyi tamamla

            //DOĞRU KART GİRİŞİ

            Thread.sleep(3000);
            driver.findElement(xpath("//*[@id=\"credit_card_number\"]")).clear();
            Thread.sleep(3000);

            String dogruKartNumaralari[] = {"5890040000000016", "4766620000000001", "4987490000000002", "5170410000000004", "4475050000000003", "5504720000000003", "4543590000000006", "4157920000000002", "5168880000000002"};
            Random dogrukartrand = new Random();
            int n = dogrukartrand.nextInt(dogruKartNumaralari.length);
            Thread.sleep(3000);
            String dogruKart = dogruKartNumaralari[n];
            System.out.println("Doğru Kart Numarası = " + dogruKart);
            driver.findElement(xpath("//*[@id=\"credit_card_number\"]")).sendKeys(dogruKart);
            Thread.sleep(3000);

            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]/div/div[3]/div/div[2]/div[2]")).click();  // ödeme yap
            Thread.sleep(3000);

            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]/div/div[1]/button")).click();  // ödeme yap
            Thread.sleep(3000);

            //driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div/a[5]")).click(); // ödemeler

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    @Test(priority = 3)

    public void terminalEkle() {

        try {

            test = extent.createTest("Terminal Ekle");
            //terminale git
            // driver.findElement(xpath("/html/body/div[1]/div/div[2]/div/div/button")).click(); // yönetici
            // Thread.sleep(1000);
            //  driver.findElement(xpath("/html/body/div[1]/div/div[2]/div/ul/li[2]/a")).click(); //ayarlar
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div/a[3]")).click(); // lisanslar
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]/div[1]/button")).click(); // ek terminal ekle
            Thread.sleep(1000);
            // ek terminal ödeme


            //şube seçimi RANDOM
            WebElement branch = driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]/div/div/div[3]/div[2]/div/div/div/div/div[1]/div/div/div[1]/div[2]"));
            WebElement branchinput = driver.findElement(xpath("//input[@id='branch_id']"));
            branch.click();
            Thread.sleep(3000);

            String subeler[] = {"Tunalı", "Çayyolu"};

            Random randomsube = new Random();

            int x = randomsube.nextInt(subeler.length);

            String subeadırandom = subeler[x];

            System.out.println("Şube adı=" + subeadırandom);
            branchinput.sendKeys(subeadırandom);
            Thread.sleep(1000);
            branchinput.click();
            branchinput.sendKeys(Keys.ENTER);
            Thread.sleep(3000);


            //terminal adı
            driver.findElement(xpath("//*[@id=\"terminal\"]")).sendKeys("Yeni Kasa");
            //ödeme adımına geç
            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]/div/div/div[4]/button")).click();
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]/div/div/div[3]/div[2]/div[1]/div[2]")).click(); //başka bir kart kullan
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]/div/div/div[3]/div[2]/div[1]/div[2]/div/a")).click();

            // Hatalı kart kodları

            //HATALI KART GİRİŞİ-1
            //kart numarası gir

            String hataliKartNumaralari[] = {"5406670000000009", "4111111111111129", "4129111111111111", "4151111111111112", "4127111111111113", "4126111111111114", "4125111111111115", "4124111111111116", "4123111111111117", "4130111111111118", "4121111111111119", "4120111111111110", "4130111111111118", "4131111111111117", "4141111111111115", "4128111111111112", "4111111111111129", "4151111111111393", "5406670000000009"};
            Random hatalikartrand = new Random();
            int num = hatalikartrand.nextInt(hataliKartNumaralari.length);

            String hataliKart = hataliKartNumaralari[num];

            System.out.println("Birinci Hatalı Kart Numarası= " + hataliKart);

            driver.findElement(xpath("//*[@id=\"credit_card_number\"]")).sendKeys(hataliKart);
            Thread.sleep(1000);

            //kart üzerindeki isim

            driver.findElement(xpath("//*[@id=\"card_holder\"]")).sendKeys("Ahmet Yıldırım");
            //son kullanma tarihi
            Thread.sleep(1000);

            driver.findElement(xpath("//*[@id=\"card_expire_date\"]")).sendKeys("0525");

            //cvv
            Thread.sleep(1000);
            driver.findElement(xpath("//*[@id=\"card_cvv\"]")).sendKeys("123");
            //ödemeyi tamamla
            Thread.sleep(3000);

            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]/div/div/div[4]/button")).click();  //ödemeyi tamamla

            //HATALI KART GİRİŞİ-2
            Thread.sleep(3000);
            driver.findElement(xpath("//*[@id=\"credit_card_number\"]")).clear();
            Thread.sleep(1000);

            String hataliKartNumaralari2[] = {"5406670000000009", "4111111111111129", "4129111111111111", "4151111111111112", "4127111111111113", "4126111111111114", "4125111111111115", "4124111111111116", "4123111111111117", "4130111111111118", "4121111111111119", "4120111111111110", "4130111111111118", "4131111111111117", "4141111111111115", "4128111111111112", "4111111111111129", "4151111111111393", "5406670000000009"};
            Random hatalikartrand2 = new Random();
            int number = hatalikartrand2.nextInt(hataliKartNumaralari2.length);

            String hataliKart2 = hataliKartNumaralari2[number];
            System.out.println("İkinci Hatalı Kart Numarası = " + hataliKart2);
            driver.findElement(xpath("//*[@id=\"credit_card_number\"]")).sendKeys(hataliKart2);
            Thread.sleep(3000);

            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]/div/div/div[4]/button")).click();  //ödemeyi tamamla

            //DOĞRU KART GİRİŞİ

            Thread.sleep(3000);
            driver.findElement(xpath("//*[@id=\"credit_card_number\"]")).clear();
            Thread.sleep(1000);

            String dogruKartNumaralari[] = {"5890040000000016", "4766620000000001", "4987490000000002", "5170410000000004", "4475050000000003", "5504720000000003", "4543590000000006", "4157920000000002", "5168880000000002"};
            Random dogrukartrand = new Random();
            int n = dogrukartrand.nextInt(dogruKartNumaralari.length);

            String dogruKart = dogruKartNumaralari[n];
            System.out.println("Doğru Kart Numarası = " + dogruKart);
            driver.findElement(xpath("//*[@id=\"credit_card_number\"]")).sendKeys(dogruKart);
            Thread.sleep(3000);

            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]/div/div/div[4]/button")).click();  //ödemeyi tamamla

            driver.findElement(xpath("/html[1]/body[1]/div[1]/main[1]/div[1]")).click();


            //  driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]/div/div/div[4]/button")).click(); // lisanslara geri dön

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    @Test(priority = 4)
    public void basitUrunEkle() {
        try {
            test = extent.createTest("Basit Ürün Ekle");
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/div/nav/ul[1]/li[2]/div/button")).click(); //Ürün Label
            Thread.sleep(3000);
            driver.findElement(xpath("/html[1]/body[1]/div[1]/div[1]/nav[1]/ul[1]/li[2]/ul[1]/li[1]/a[1]")).click(); //Ürün Listeleme
            Thread.sleep(3000);
            driver.findElement(xpath("//button[@class='u-margin-left-10 btn btn-primary']")).click(); // Ürün Ekle
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]")).click(); // Basit Ürün Ekle
            Thread.sleep(3000);

            //ürün adı random


            String basicProductNames[] = {"Çanta", "Gözlük", "Kolye", "Küpe", "Bilezik", "Halhal", "Saat", "Bardak", "Anahtarlık", "Toka"};

            Random rand = new Random();

            int n = rand.nextInt(basicProductNames.length);

            String productNameBasic = basicProductNames[n];
            productNameBasic += "-" + new Date().getTime();
            String selectedBasicProductName = productNameBasic;

            System.out.println(basicProductNames[n]);

            driver.findElement(xpath(" //*[@id=\"name\"]")).sendKeys(selectedBasicProductName);

            Thread.sleep(3000);
            driver.findElement(xpath("//*[@id=\"sell_price\"]")).sendKeys("35"); // satış fiyatı
            Thread.sleep(3000);


            //ETİKET OLUŞTURMA

            WebElement Etiket = driver.findElement(xpath("//div[@class='Basic tab']//div[@class='multiselect tag']"));
            WebElement etiketInput = driver.findElement(xpath("//input[@id='tag_ids']"));
            Etiket.click();
            Thread.sleep(3000);
            etiketInput.sendKeys("Mutfak");
            etiketInput.sendKeys(Keys.ENTER);


            WebElement x = driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]/div[1]/div[3]/div[2]/div/div[1]/div[2]"));
            TagInnerText = x.getText();
            System.out.println("Etiket Adı :" + TagInnerText);

            Thread.sleep(5000);
            //TAX OLUŞTURMA


            WebDriverWait taxwait = new WebDriverWait(driver, 10);
            WebElement tax = taxwait.until(
                    ExpectedConditions.visibilityOfElementLocated(xpath("//div[@class='Form-item required']//div[@class='multiselect__tags']")));


            //WebElement tax = driver.findElement(xpath("//div[@class='Form-item required']//div[@class='multiselect__tags']"));
            WebElement taxinput = driver.findElement(xpath("//input[@id='tax_id']"));
            tax.click();
            Thread.sleep(1000);
            taxinput.sendKeys("%18");
            Thread.sleep(1000);
            taxinput.click();
            taxinput.sendKeys(Keys.ENTER);
            Thread.sleep(1000);


            driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div[2]/template/div/div")).click(); // kaydet
            Thread.sleep(3000);


            // POS EKRANINA GİT

            driver.findElement(xpath("//a[@class='web btn btn-primary']")).click(); // pos ekranına gider
            Thread.sleep(8000);


            //RANDOM ŞUBE SEÇİMİ

          //  WebDriverWait wait = new WebDriverWait(driver, 10);
          //   WebElement BranchesTypesContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(xpath("/html/body/div[2]/div/div/div[3]/div")));


           WebElement BranchesTypesContainer = driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div"));
            List<WebElement> BranchesTypes = BranchesTypesContainer.findElements(By.xpath("./*"));
            Random BranchesTypeRandom = new Random();
            int BrunchesTypeCount = BranchesTypes.size();
            int BrunchesTypeIndex = BranchesTypeRandom.nextInt(BrunchesTypeCount);
            BranchesTypes.get(BrunchesTypeIndex).click();
            Thread.sleep(5000);


            //RANDOM KASA SEÇİMİ

            WebElement TerminalTypesContainer = driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div"));
            List<WebElement> TerminalTypes = TerminalTypesContainer.findElements(By.xpath("./*"));
            Random TerminalTypeRandom = new Random();
            int TerminalTypesTypeCount = TerminalTypes.size();
            int TerminalTypesIndex = TerminalTypeRandom.nextInt(TerminalTypesTypeCount);

            WebElement selectedTerminal = TerminalTypes.get(TerminalTypesIndex);
            String className1 = selectedTerminal.getAttribute("class");
            System.out.println(className1);
            selectedTerminal.click();
            Thread.sleep(3000);

            String className = "terminal btn btn-line-white is-open";
            System.out.println(className);
            Thread.sleep(2000);


            if (className1.equals(className)) {

                driver.findElement(xpath("/html/body/div[2]/div/div/div[4]/div/div[3]/button[2]")).click();
            } else {

                driver.findElement(xpath("//*[@id=\"open_balance\"]")).sendKeys("100");

                driver.findElement(xpath("//button[@class='btn btn-blue btn-wide']")).click();
            }


            //ÜRÜN SEÇİMİ

            WebElement TagTypesAll = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div"));
            List<WebElement> TagTypes = TagTypesAll.findElements(By.xpath("./*"));


            for (WebElement tagElement : TagTypes) {
                String tagText = tagElement.getText();
                if (tagText.equals(TagInnerText)) {
                    tagElement.click();
                    break;
                }
            }


            //ÜRÜN SEPETE AT

            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[1]/div/button[2]")).click();  // ürünü sepete at
            Thread.sleep(3000);
            driver.findElement(xpath("//button[@class='paid btn btn-green']")).click();  //pay
            Thread.sleep(5000);


            //RANDOM ÖDEME SEÇİMİ

            WebElement paymentTypesContainer = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]"));
            List<WebElement> paymentTypes = paymentTypesContainer.findElements(By.xpath("./*"));
            Random paymentTypeRandom = new Random();
            int paymentTypeCount = paymentTypes.size();
            int paymentTypeIndex = paymentTypeRandom.nextInt(paymentTypeCount);
            WebElement paymentTypeElement = paymentTypes.get(paymentTypeIndex);
            String paymentTypeName = paymentTypeElement.getText();
            paymentTypeElement.click();
            Thread.sleep(2000);


            WebDriverWait bekle = new WebDriverWait(driver, 10);
            WebElement nokta = bekle.until(ExpectedConditions.visibilityOfElementLocated(xpath("//button[@class='btn menu']")));// 3 nokta
            nokta.click();


            //driver.findElement(xpath("//button[@class='btn menu']")).click(); // 3 nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi
            Thread.sleep(3000);
            //CHECK RESULT

            List<WebElement> paymentTyperowsize = driver.findElements(xpath("//tr[*]//td[4]"));
            System.out.println("İşlem sayısı : " + paymentTyperowsize.size());
            String foundPaymentType = driver.findElement(xpath("//tr[1]//td[4]")).getText();
            if (foundPaymentType.equals(paymentTypeName)) {
                System.out.println("Ödeme Tipi Eşit");
            } else {
                System.out.println("Ödeme Tipi Eşit Değil");





            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    @Test(priority = 5)
    public void VaryantlıUrunEkle() {

        try {
            test = extent.createTest("Varyantlı Ürün Ekle");
//satış ekranına geri dön
            Thread.sleep(3000);
            driver.get(POSmenuUrl);//üç nokta //üç nokta
            Thread.sleep(3000);
            driver.get(YonetimPaneliUrl);
            Thread.sleep(3000);


            driver.findElement(xpath("/html/body/div[1]/div[1]/nav/ul[1]/li[2]")).click(); //Ürün Label
            Thread.sleep(3000);
            driver.findElement(xpath("/html[1]/body[1]/div[1]/div[1]/nav[1]/ul[1]/li[2]/ul[1]/li[1]/a[1]")).click(); //Ürün Listeleme
            Thread.sleep(3000);
            driver.findElement(xpath("//button[@class='u-margin-left-10 btn btn-primary']")).click(); // Ürün Ekle
            Thread.sleep(3000);
            driver.findElement(xpath("/html[1]/body[1]/div[1]/main[1]/div[1]/div[2]/div[1]/div[2]")).click(); // Varyantlı Ürün Ekle
            Thread.sleep(3000);
            driver.findElement(xpath("//input[@id='name']")).sendKeys("Prada 123"); // Basit Ürün isim
            Thread.sleep(3000);


            //ETİKET OLUŞTURMA

            WebElement Etiket = driver.findElement(xpath("//div[@class='tag']//div[@class='multiselect__tags']"));
            WebElement etiketInput = driver.findElement(xpath("//input[@id='tag_ids']"));
            Etiket.click();
            Thread.sleep(3000);
            etiketInput.sendKeys("Trend Gözlükler");
            etiketInput.sendKeys(Keys.ENTER);


            WebElement x = driver.findElement(xpath("//div[@class='tag']//div[@class='multiselect__tags']"));
            String TagInnerText = x.getText();
            System.out.println("Etiket Adı :" + TagInnerText);


            //TAX OLUŞTURMA
            WebElement tax = driver.findElement(xpath("//div[@class='Form-item required']//div[@class='multiselect__tags']"));
            WebElement taxinput = driver.findElement(xpath("//input[@id='tax_id']"));
            tax.click();
            Thread.sleep(1000);
            taxinput.sendKeys("%18");
            Thread.sleep(3000);
            taxinput.click();
            taxinput.sendKeys(Keys.ENTER);
            Thread.sleep(1000);


            // Varyant Ekleme

            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[2]/div/div[3]")).click();

            WebElement varyant = driver.findElement(xpath("//div[@class='variation']//div[@class='multiselect__tags']"));
            WebElement varyantinput = driver.findElement(xpath("//input[@id='variation_type']"));
            varyant.click();
            Thread.sleep(1000);
            varyantinput.sendKeys("Cam Rengi");
            Thread.sleep(1000);
            varyantinput.click();
            varyantinput.sendKeys(Keys.ENTER);
            Thread.sleep(1000);

            // Varyasyon Değeri Ekleme

            WebElement varyantdegeri = driver.findElement(xpath("//div[@class='multiselect tag is-danger']//div[@class='multiselect__tags']"));
            WebElement varyantdegeriinput = driver.findElement(xpath("//input[@id='variation_values']"));
            varyantdegeri.click();
            Thread.sleep(1000);
            varyantdegeriinput.sendKeys("FÜME");
            varyantdegeriinput.sendKeys(Keys.ENTER);


            varyantdegeriinput.sendKeys("GRİ");
            varyantdegeriinput.sendKeys(Keys.ENTER);

            varyantdegeriinput.sendKeys("COPPER FLASH");
            varyantdegeriinput.sendKeys(Keys.ENTER);

            Thread.sleep(1000);

            // SATIŞ FİYATI


            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[2]/div/div[5]")).click();


            driver.findElement(xpath("//div[@class='Price tab']//div[1]//div[1]//div[1]//div[2]//div[1]//div[1]//div[1]//input[1]")).sendKeys("1200");
            Thread.sleep(1000);
            driver.findElement(xpath("//div[@class='Price tab']//div[@class='drag-container']//div[2]//div[1]//div[1]//div[2]//div[1]//div[1]//div[1]//input[1]")).sendKeys("1200");
            Thread.sleep(1000);
            driver.findElement(xpath("//div[@class='Price tab']//div[@class='AccordionTable']//div[3]//div[1]//div[1]//div[2]//div[1]//div[1]//div[1]//input[1]")).sendKeys("1200");


            Thread.sleep(1000);

            //varyantlı ÜRÜN KAYDET

            driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div[2]/template/div/div")).click();

            Thread.sleep(5000);


            // POS EKRANINA GİT

            driver.findElement(xpath("//a[@class='web btn btn-primary']")).click(); // pos ekranına gider
            Thread.sleep(10000);


            //RANDOM ŞUBE SEÇİMİ


            WebDriverWait wait = new WebDriverWait(driver, 10);
            WebElement BranchesTypesContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(xpath("/html/body/div[2]/div/div/div[3]/div")));

            //  WebElement BranchesTypesContainer = driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div"));
            Thread.sleep(1000);
            List<WebElement> BranchesTypes = BranchesTypesContainer.findElements(By.xpath("./*"));
            Thread.sleep(1000);
            Random BranchesTypeRandom = new Random();
            int BrunchesTypeCount = BranchesTypes.size();
            int BrunchesTypeIndex = BranchesTypeRandom.nextInt(BrunchesTypeCount);
            WebElement aa = BranchesTypes.get(BrunchesTypeIndex);
            aa.click();
            Thread.sleep(5000);


            //RANDOM KASA SEÇİMİ

            WebElement TerminalTypesContainer = driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div"));
            List<WebElement> TerminalTypes = TerminalTypesContainer.findElements(By.xpath("./*"));
            Random TerminalTypeRandom = new Random();
            int TerminalTypesTypeCount = TerminalTypes.size();
            int TerminalTypesIndex = TerminalTypeRandom.nextInt(TerminalTypesTypeCount);

            WebElement selectedTerminal = TerminalTypes.get(TerminalTypesIndex);
            String className1 = selectedTerminal.getAttribute("class");
            System.out.println(className1);
            selectedTerminal.click();
            Thread.sleep(3000);

            String className = "terminal btn btn-line-white is-open";
            System.out.println(className);
            Thread.sleep(2000);


            if (className1.equals(className)) {

                driver.findElement(xpath("/html/body/div[2]/div/div/div[4]/div/div[3]/button[2]")).click();  // kasa açıksa
            } else {

                driver.findElement(xpath("//*[@id=\"open_balance\"]")).sendKeys("100");   // kasa kapalıysa

                driver.findElement(xpath("//button[@class='btn btn-blue btn-wide']")).click();
            }


            //ÜRÜN SEÇİMİ

            WebElement TagTypesAll = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div"));
            List<WebElement> TagTypes = TagTypesAll.findElements(By.xpath("./*"));

            for (WebElement tagElement : TagTypes) {
                String tagText = tagElement.getText();
                if (tagText.equals(TagInnerText)) {
                    tagElement.click();
                    break;
                }
            }


            Thread.sleep(3000);


            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[1]/div/button[2]")).click();  // ürünü sepete at
            Thread.sleep(3000);


            //ÜRÜN varyant değeri seç


            WebElement variantTypesContainer = driver.findElement(xpath("//div[@class='variations']"));
            List<WebElement> variantTypes = variantTypesContainer.findElements(By.xpath("./*"));

            Random variantTypeRandom = new Random();
            int variantTypeCount = variantTypes.size();
            int variantTypeIndex = variantTypeRandom.nextInt(variantTypeCount);

            WebElement variantTypeElement = variantTypes.get(variantTypeIndex);
            variantTypeElement.click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[4]/button")).click();
            Thread.sleep(5000);
            //ödeme

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/div[2]/div[2]/button[3]")).click();  //pay
            Thread.sleep(5000);

            //RANDOM ÖDEME SEÇİMİ

            WebElement paymentTypesContainer = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]"));
            List<WebElement> paymentTypes = paymentTypesContainer.findElements(By.xpath("./*"));
            Random paymentTypeRandom = new Random();
            int paymentTypeCount = paymentTypes.size();
            int paymentTypeIndex = paymentTypeRandom.nextInt(paymentTypeCount);
            WebElement paymentTypeElement = paymentTypes.get(paymentTypeIndex);
            String paymentTypeName = paymentTypeElement.getText();
            paymentTypeElement.click();
            Thread.sleep(3000);


            // Satış Geçmişi


            driver.findElement(xpath("//button[@class='btn menu']")).click(); // 3 nokta
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi
            Thread.sleep(5000);

            //CHECK RESULT

            List<WebElement> paymentTyperowsize = driver.findElements(xpath("//tr[*]//td[4]"));
            System.out.println("İşlem sayısı : " + paymentTyperowsize.size());
            String foundPaymentType = driver.findElement(xpath("//tr[1]//td[4]")).getText();
            if (foundPaymentType.equals(paymentTypeName)) {
                System.out.println("Ödeme Tipi Eşit");
            } else {
                System.out.println("Ödeme Tipi Eşit Değil");
            }


        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    @Test(priority = 6)
    public void hizliUrunEkle() {

        try {
            test = extent.createTest("Hızlı Ürün Ekle");
            //satış ekranına geri dön
            Thread.sleep(3000);
            driver.get(POSmenuUrl);//üç nokta
            Thread.sleep(3000);
            driver.get(YonetimPaneliUrl);
            Thread.sleep(5000);
          //  WebDriverWait wait = new WebDriverWait(driver, 10);
          //  WebElement element = wait.until(
          //          ExpectedConditions.visibilityOfElementLocated(xpath("/html/body/div[1]/div[1]/nav/ul[1]/li[2]")));
          //  element.click();

            driver.findElement(xpath("/html/body/div[1]/div[1]/nav/ul[1]/li[2]")).click(); //Ürün Label
            Thread.sleep(3000);

            driver.findElement(xpath("/html[1]/body[1]/div[1]/div[1]/nav[1]/ul[1]/li[2]/ul[1]/li[1]/a[1]")).click(); //Ürün Listeleme
            Thread.sleep(3000);

            driver.findElement(xpath("//button[@class='u-margin-left-10 btn btn-primary fast-create']")).click(); // Ürün Ekle

            Thread.sleep(3000);

            // driver.findElement(xpath("//input[@id='sell_price']")).sendKeys("250");

            Thread.sleep(1000);

            //String uuid = UUID.randomUUID().toString();
            // driver.findElement(xpath("//input[@id='sell_price']")).sendKeys(uuid);


            //ürün adı random


            String Productnames[] = {"Çanta", "Gözlük", "Kolye", "Küpe", "Bilezik", "Halhal", "Saat", "Bardak", "Anahtarlık", "Toka"};

            Random rand = new Random();

            int n = rand.nextInt(Productnames.length);

            String productName = Productnames[n];
            productName += "-" + new Date().getTime();
            String selectedProductName = productName;

            System.out.println(Productnames[n]);

            driver.findElement(xpath("//input[@id='name']")).sendKeys(selectedProductName);


            Thread.sleep(1000);


            // ürün fiyatı random


            Random r = new Random();
            int number = r.nextInt(1000) + 1;
            String newstr = Integer.toString(number);
            System.out.println(newstr);
            driver.findElement(xpath("//input[@id='sell_price']")).sendKeys(newstr);


            //Select tax = new Select(driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div/div/div[3]/div[1]/div[2]/div[2]/div/div/div[1]/div[2]")));
            //tax.selectByVisibleText("%8");

            driver.findElement(xpath(" //div[@class='LoadingButton save-btn blue']//div[@class='content']")).click();  // hızlı ürünü kaydeder
            Thread.sleep(3000);
            driver.findElement(xpath("//a[@class='web btn btn-primary']")).click(); // pos ekranına gider
            Thread.sleep(3000);

            driver.findElement(xpath("//html/body/div[2]/div/div/div[3]/div/button[2]")).click(); // çayyolu şubesini seçer

            Thread.sleep(1000);

            //kasa random

            WebElement TerminalTypesContainer = driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div"));
            List<WebElement> TerminalTypes = TerminalTypesContainer.findElements(By.xpath("./*"));
            Random TerminalTypeRandom = new Random();
            int TerminalTypesTypeCount = TerminalTypes.size();
            int TerminalTypesIndex = TerminalTypeRandom.nextInt(TerminalTypesTypeCount);

            WebElement selectedTerminal = TerminalTypes.get(TerminalTypesIndex);
            String className1 = selectedTerminal.getAttribute("class");
            System.out.println(className1);
            selectedTerminal.click();
            Thread.sleep(3000);

            String className = "terminal btn btn-line-white is-open";
            System.out.println(className);
            Thread.sleep(2000);


            if (className1.equals(className)) {

                driver.findElement(xpath("/html/body/div[2]/div/div/div[4]/div/div[3]/button[2]")).click();
            } else {

                driver.findElement(xpath("//*[@id=\"open_balance\"]")).sendKeys("100");

                driver.findElement(xpath("//button[@class='btn btn-blue btn-wide']")).click();
            }

            Thread.sleep(3000);


            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/div[1]/div/input")).sendKeys(selectedProductName); // ürünü seç
            Thread.sleep(3000);

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div")).click();  // ürünü sepete at
            Thread.sleep(3000);

            driver.findElement(xpath("//button[@class='paid btn btn-green']")).click();  //pay
            Thread.sleep(3000);


            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[1]/div")).click(); //cash
            Thread.sleep(3000);

/*
            WebElement cash; // cash
            cash = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[1]/div"));
            WebElement credit; //credit
            credit = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[2]/div"));
            WebElement giftcard; // gift card
            giftcard = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[3]/div"));

            String paymenttype[] = {cash,credit,giftcard};

            Random ran = new Random();

            int x = ran.nextInt(paymenttype.length);


            String paymenttypename = paymenttype[x];

            System.out.println( paymenttype[x] );

            WebElement son = paymenttypename;
            son.click();

*/

            WebDriverWait waitdot = new WebDriverWait(driver, 10);
            WebElement elementdot = waitdot.until(
                    ExpectedConditions.visibilityOfElementLocated(xpath("//button[@class='btn menu']")));
            elementdot.click();  // üç nokta


            // driver.findElement(xpath("//button[@class='btn menu']")).click(); // 3 nokta
            Thread.sleep(1000);

            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi


        } catch (InterruptedException e) {

            e.printStackTrace();
        }

    }


    @Test(priority = 7)
    public void siparisOluştur() {

        try {
            test = extent.createTest("Sipariş Oluştur");
//satış ekranına geri dön
            Thread.sleep(3000);
            driver.get(POSmenuUrl);//üç nokta
            Thread.sleep(3000);
            driver.get(YonetimPaneliUrl);
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[1]/div[1]/nav/ul[1]/li[2]")).click(); //Ürün Label
            Thread.sleep(1000);
            driver.findElement(xpath("/html[1]/body[1]/div[1]/div[1]/nav[1]/ul[1]/li[2]/ul[1]/li[1]/a[1]")).click(); //Ürün Listeleme
            Thread.sleep(1000);


            String searchProductNames[] = {"Masa Lambası", "Kürk"};

            Random rand = new Random();

            int n = rand.nextInt(searchProductNames.length);

            String productName = searchProductNames[n];

            System.out.println("Ürün adı=" + searchProductNames[n]);

            driver.findElement(xpath("/html/body/div[1]/main/div/div/div[1]/div[1]/div[1]/input")).sendKeys(productName);
            Thread.sleep(5000);
            driver.findElement(xpath("/html[1]/body[1]/div[1]/main[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]")).click();


            // ilk stok miktarı

            Thread.sleep(5000);
            WebElement firstStockQuantity = driver.findElement(By.xpath("/html/body/div[1]/main/div/div[2]/div[3]/div/div/div[2]/div[2]/div/div[2]/div[2]"));

            String firstStockQuantityAttribute = firstStockQuantity.getText();
            int firstStockQuantityAttributeInt = Integer.parseInt(firstStockQuantityAttribute);
            System.out.println("ilk ürün Stok Miktarı =" + firstStockQuantityAttributeInt);

            // sol İçerik sekme

            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/div/nav/ul[1]/li[2]/ul/li[3]/a")).click(); // İçerik Listeleme
            Thread.sleep(1000);


            String searchIngredientNames[] = {"Nane", "Süt", "Tarçın"};

            Random randomIngredient = new Random();

            int y = randomIngredient.nextInt(searchIngredientNames.length);

            String IngredientName = searchIngredientNames[y];

            System.out.println("İçerik Adı=" + searchIngredientNames[y]);
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[1]/main/div/div/div[1]/div[1]/div/input")).sendKeys(IngredientName);

            driver.findElement(xpath("/html/body/div[1]/main/div/div/div[2]/div[1]/div/div/div/div/div[1]/div[2]/div/div")).click();


            // ilk içerik miktarı******************************


            //1.yol
/*
            Thread.sleep(5000);
            WebElement firstIngredientQuantity = driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div/div[2]/div/div[5]/div/table/tbody/tr[2]/td[2]"));

            String firstStockIngredientQuantityAttribute = firstIngredientQuantity.getAttribute("value");

            System.out.println("İçerik Stok Sayısı =" + firstStockIngredientQuantityAttribute);

            Thread.sleep(1000);

*/
            Thread.sleep(8000);

            //kaydet
            driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div/div[3]/button[2]/span")).click();


            //2.yol ilk içerik miktarı
            Thread.sleep(3000);
            driver.findElement(xpath("//li[@class='NavigationLink report']//button[@class='toggle btn btn-small btn-icon']")).click();
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[1]/div/nav/ul[1]/li[6]/ul/li[6]/a")).click();


            WebElement firstIngredientQuantitySearch = driver.findElement(xpath("/html/body/div[1]/main/div/div[3]/div/div[1]/div[1]/div/input"));
            firstIngredientQuantitySearch.sendKeys(IngredientName);
            WebElement firstIngredientQuantitySearchClick = driver.findElement(xpath("/html/body/div[1]/main/div/div[3]/div/div[2]/div[1]/div/div/div/div/div[3]/div[2]/div/div"));
            String firstStockIngredientQuantityAttribute = firstIngredientQuantitySearchClick.getText();

            System.out.println("İlk içerik Stok Miktarı =" + firstStockIngredientQuantityAttribute);


            //Envanter
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/div/nav/ul[1]/li[5]/div/div")).click(); // Envanter
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[1]/div/nav/ul[1]/li[5]/ul/li[2]/a")).click(); // Siparişler
            Thread.sleep(3000);
            driver.findElement(xpath("//button[@class='btn btn-primary']")).click(); // Sipariş  Ekle
            Thread.sleep(3000);

            //irsaliye no

            // driver.findElement(xpath(" //*[@id=\"order_number\"] ")).sendKeys("0000");
            //  Thread.sleep(1000);


            Random ir = new Random();
            int irsaliye = ir.nextInt(100);
            String newirsaliye = Integer.toString(irsaliye);
            System.out.println("İrsaliye no=" + newirsaliye);
            driver.findElement(xpath("//*[@id=\"order_number\"]")).click();
            driver.findElement(xpath("//*[@id=\"order_number\"]")).sendKeys(newirsaliye);


            // Tedarikçi

            WebElement vendor = driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[1]/div[2]/div[1]/div/div/div[1]/div[2]"));
            WebElement vendorinput = driver.findElement(xpath("//input[@id='vendor_id']"));
            vendor.click();
            Thread.sleep(1000);
            vendorinput.sendKeys("Pembe Giyim");
            Thread.sleep(1000);
            vendorinput.click();
            vendorinput.sendKeys(Keys.ENTER);
            Thread.sleep(1000);


            //sevk edilecek şube


            WebElement branch = driver.findElement(xpath("/html[1]/body[1]/div[1]/main[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]"));
            WebElement branchinput = driver.findElement(xpath("//input[@id='branch_id']"));
            branch.click();
            Thread.sleep(1000);
            branchinput.sendKeys("Tunalı");
            Thread.sleep(1000);
            branchinput.click();
            branchinput.sendKeys(Keys.ENTER);
            Thread.sleep(1000);


            //Beklenen Sevk Tarihi

            WebElement arrival = driver.findElement(xpath("/html[1]/body[1]/div[1]/main[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/input[2]"));
            arrival.click();
            Thread.sleep(1000);
            WebElement arrivaldate = driver.findElement(xpath("/html/body/div[4]/div[2]/div/div[2]/div/span[31]"));
            arrivaldate.click();
            Thread.sleep(1000);

            //ürünler - alt sekme

            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[2]/div[2]")).click();

            //ürün search

            //  WebElement search=driver.findElement(xpath("/html[1]/body[1]/div[1]/main[1]/div[1]/div[2]/div[1]/div[3]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/input[1]"));
            // search.sendKeys("Kürk");
            //  driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[3]/div[2]/div/div[1]/div[3]/div/div")).click();


            driver.findElement(xpath("/html[1]/body[1]/div[1]/main[1]/div[1]/div[2]/div[1]/div[3]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/input[1]")).sendKeys(productName);

            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[3]/div[2]/div/div[1]/div[3]/div/div")).click();

            //sipariş ürün miktar

            Random order = new Random();
            int orderQuantityAttribute = order.nextInt(10) + 1;

            String orderQuantity = Integer.toString(orderQuantityAttribute);
            System.out.println("Ürün Sipariş Miktarı=" + orderQuantity);

            driver.findElement(xpath("//input[@id='quantity']")).clear();
            driver.findElement(xpath("//input[@id='quantity']")).sendKeys(orderQuantity);


            Thread.sleep(3000);

            //ürün fiyat

            // driver.findElement(xpath("//input[@name='buy_price']")).click();
            // driver.findElement(xpath("//input[@name='buy_price']")).sendKeys("300");
            // Thread.sleep(1000);

            Random r = new Random();
            int number = r.nextInt(100) + 1;
            String newstr = Integer.toString(number);
            System.out.println("Ürün Fiyat=" + newstr);
            driver.findElement(xpath("//input[@name='buy_price']")).click();
            driver.findElement(xpath("//input[@name='buy_price']")).sendKeys(newstr);

            Thread.sleep(3000);


            //alt sekme içerik ekleme

            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[2]/div[3]")).click();


            //içerik search

            driver.findElement(xpath("//div[@class='IngredientOrders']//input[@id='order_number']")).sendKeys(IngredientName);
            Thread.sleep(3000);

            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[3]/div[3]/div/div[1]/div[2]/div/div")).click();

            Thread.sleep(3000);

            //sipariş içerik miktar

            Random ingredientRandom = new Random();
            int ingredientQuantity = ingredientRandom.nextInt(100) + 1;

            String ingredient = Integer.toString(ingredientQuantity);
            System.out.println("içerik Sipariş Miktarı =" + ingredient);


            WebElement element = driver.findElement(xpath("(/html/body/div[1]/main/div/div[2]/div/div[3]/div[3]/div/div[2]/div[2]/div/div/div[2]/div/div)"));
            Actions actions = new Actions(driver);
            actions.moveToElement(element).click().sendKeys(ingredient).build().perform();


            // içerik fiyat


            Random newrandom = new Random();
            int num = newrandom.nextInt(100) + 1;
            String newcost = Integer.toString(num);
            System.out.println("İçerik Fiyat=" + newcost);
            driver.findElement(xpath("//input[@id='buy_price']")).click();
            driver.findElement(xpath("//input[@id='buy_price']")).sendKeys(newcost);

            Thread.sleep(3000);


            //kaydet ve onayla

            driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div[2]/template/div/button[2]/span")).click();
            Thread.sleep(3000);

            // siparişe tıkla
            driver.findElement(xpath("/html/body/div[1]/main/div/div/div[2]/div[2]/div[1]/div/div/div/div[1]/div[2]/div/div/div")).click();
            Thread.sleep(3000);

            //ürünler

            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[2]/div[2]")).click(); //ürünler sekmesi
            Thread.sleep(1000);

            //alındı

            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[3]/div[2]/div/div/div[1]/div/div[7]")).click(); //üç nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[3]/div[2]/div/div/div[1]/div/div[8]/button[1]")).click(); //alındı
            Thread.sleep(1000);

            //içerik sekmesi

            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[2]/div[3]")).click();
            Thread.sleep(3000);

            //alındı

            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[3]/div[3]/div/div/div[1]/div/div[6]")).click(); //üç nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[3]/div[3]/div/div/div[1]/div/div[7]/button[1]")).click(); //alındı
            Thread.sleep(1000);


            //kaydet ve tamamla

            driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div[2]/template/div/button[3]/span")).click();
            Thread.sleep(4000);


            //ürünler

            //  driver.findElement(xpath("/html/body/div[1]/div[1]/nav/ul[1]/li[2]")).click(); //Ürün Label
            Thread.sleep(1000);
            driver.findElement(xpath("/html[1]/body[1]/div[1]/div[1]/nav[1]/ul[1]/li[2]/ul[1]/li[1]/a[1]")).click(); //Ürün Listeleme
            Thread.sleep(1000);

            //ürün search
            driver.findElement(xpath("/html/body/div[1]/main/div/div/div[1]/div[1]/div[1]/input")).clear();
            driver.findElement(xpath("/html/body/div[1]/main/div/div/div[1]/div[1]/div[1]/input")).sendKeys(productName);
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/main/div/div/div[2]/div[2]/div[1]/div/div/div/div[1]/div[2]/div/div/div")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div[2]/div/div/div[1]/div/div[2]")).click();

            driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div[2]/template/div[1]")).click(); //üç nokta
            Thread.sleep(3000);

            driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div[2]/template/div[1]/div/div[3]/div[2]")).click(); //stok görüntüleme


            WebElement laststock = driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div/div[2]/div[2]/table/tbody/tr[1]/td[3]/span[3]"));  //GÖRMÜYOR XPATH


            String lastStockCountString = laststock.getText();

            System.out.println("Son Ürün Stok Miktarı =" + lastStockCountString);
            Thread.sleep(7000);

            driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div[1]/button")).click(); //çıkış


            //sol  içerik sekmesi


            //  driver.findElement(xpath("/html/body/div[1]/div[1]/nav/ul[1]/li[2]")).click(); //Ürün Label
            //     Thread.sleep(3000);


            // son içerik miktarı görüntüleme


            // 1.yol

            /*
            driver.findElement(xpath("/html/body/div[1]/div/nav/ul[1]/li[2]/ul/li[3]/a")).click(); // İçerik
            Thread.sleep(3000);

            driver.findElement(xpath("/html/body/div[1]/main/div/div/div[1]/div[1]/div/input")).sendKeys(IngredientName); //içerik search
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[1]/main/div/div/div[2]/div[1]/div/div/div/div/div[1]/div[2]/div/div")).click();
            driver.findElement(xpath("/html/body/div[1]/main/div/div/div[1]/div[2]/div")).click();
            driver.findElement(xpath("/html/body/div[1]/main/div/div/div[1]/div[2]/div/div/div[2]")).click();
            //  driver.findElement(xpath("/html/body/div[1]/main/div/div/div[2]/div[1]/div/div/div/div/div[1]/div[2]/div/div")).click(); //içerik stok detay görüntüleme

*/

            //2.yol


            //  Thread.sleep(3000);
            //  driver.findElement(xpath("/html/body/div[1]/div/nav/ul[1]/li[6]/div/button")).click();
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[1]/div/nav/ul[1]/li[6]/ul/li[6]/a")).click();


            WebElement firstIngredientQuantitySearchLast = driver.findElement(xpath("/html/body/div[1]/main/div/div[3]/div/div[1]/div[1]/div/input"));

            firstIngredientQuantitySearchLast.sendKeys(IngredientName);
            WebElement firstIngredientQuantitySearchClickLast = driver.findElement(xpath("/html/body/div[1]/main/div/div[3]/div/div[2]/div[1]/div/div/div/div/div[3]/div[2]/div/div"));
            String firstStockIngredientQuantityAttributeLast = firstIngredientQuantitySearchClickLast.getText();

            System.out.println("Son İçerik Stok Miktarı =" + firstStockIngredientQuantityAttributeLast);


            //son stok ürün miktarı

            Thread.sleep(5000);

            //   WebDriverWait some_element = new WebDriverWait(driver,100);
            //  some_element.until(ExpectedConditions.visibilityOfElementLocated(xpath("/html[1]/body[1]/div[1]/main[1]/div[1]/div[1]/div[1]/div[2]/div[2]/table[1]/tbody[1]/tr[1]/td[3]/span[3]")));


            //check result

            int finalValue;
            int orderQuantityInteger = Integer.parseInt(orderQuantity);
            int lastStockCountInt = Integer.parseInt(lastStockCountString);


            Thread.sleep(1000);

            finalValue = firstStockQuantityAttributeInt + orderQuantityInteger;
            System.out.println("Olması gereken Stok Son =" + finalValue);

            if (finalValue == lastStockCountInt) {

                System.out.println("Stok Miktarı Doğru");
            } else {
                System.out.println("Stok Miktarı Yanlış");
            }


            String firstStockIngredientQuantityAttributeReplace = firstStockIngredientQuantityAttribute.replaceAll("[^\\d.]", "");


            String firstStockIngredientQuantityAttributeLastReplace = firstStockIngredientQuantityAttributeLast.replaceAll("[^0-9.]", "");


            //check result içerik

            int finalIngvalue;
            int IngredientQuantityInteger = Integer.parseInt(ingredient);
            int firstStockIngredientQuantityAttributeInt = Integer.parseInt(firstStockIngredientQuantityAttributeReplace);
            int firstStockIngredientQuantityAttributeLastInt = Integer.parseInt(firstStockIngredientQuantityAttributeLastReplace);

            Thread.sleep(1000);

            finalIngvalue = firstStockIngredientQuantityAttributeInt + IngredientQuantityInteger;
            System.out.println("Olması gereken İçerik Son =" + finalIngvalue);

            if (finalIngvalue == firstStockIngredientQuantityAttributeLastInt) {

                System.out.println("İçerik Miktarı Doğru");
            } else {
                System.out.println("İçerik Miktarı Yanlış");
            }


        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    @Test(priority = 8)
    public void kasadaacikvar() {

        try {
            test = extent.createTest("Kasada Açık Var");
//logout - nesliden çıkış
            driver.findElement(xpath("/html/body/div[1]/div/div[2]/div/div/button")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/div/div[2]/div/ul/li[4]/button")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/div/div[2]/div/div[2]/div/div/div[2]/div[2]/button[2]")).click();
            Thread.sleep(3000);

//login  - seyma sırdag
            driver.get(loginUrl);
            driver.findElement(name("email")).clear();
            driver.findElement(name("email")).sendKeys("nesli.necipoglu+3@ikas.com");
            Thread.sleep(1000);
            driver.findElement(name("password")).sendKeys("1988Nes.");
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/div/div/div[2]/div/div[2]/form/div[3]/button")).click();
            Thread.sleep(5000);


            //POS


            driver.findElement(xpath("/html/body/div[2]/div/div/div[2]/div/button[2]")).click(); // çayyolu
            Thread.sleep(5000);

            // random kasa

            WebElement TerminalTypesContainer = driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div"));
            List<WebElement> TerminalTypes = TerminalTypesContainer.findElements(By.xpath("./*"));
            Random TerminalTypeRandom = new Random();
            int TerminalTypesTypeCount = TerminalTypes.size();
            int TerminalTypesIndex = TerminalTypeRandom.nextInt(TerminalTypesTypeCount);

            WebElement selectedTerminal = TerminalTypes.get(TerminalTypesIndex);
            String className1 = selectedTerminal.getAttribute("class");
            System.out.println(className1);
            selectedTerminal.click();
            Thread.sleep(3000);

            String className = "terminal btn btn-line-white is-open";
            System.out.println(className);
            Thread.sleep(2000);


            if (className1.equals(className)) {

                driver.findElement(xpath("/html/body/div[2]/div/div/div[4]/div/div[3]/button[2]")).click();
            } else {

                driver.findElement(xpath("//*[@id=\"open_balance\"]")).sendKeys("100");

                driver.findElement(xpath("//button[@class='btn btn-blue btn-wide']")).click();
            }


            // 1.satış yap

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[3]/div")).click(); //kadın
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[3]/div/button[2]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/div[2]/div[2]/button[3]")).click();
            Thread.sleep(1000);

            //ÖDEME

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[3]/div")).click();


            // Satış Geçmişi
            Thread.sleep(3000);
            driver.findElement(xpath("//button[@class='btn menu']")).click(); //ÜÇ NOKTA
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi
            Thread.sleep(4000);

            WebElement first = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/table/tbody/tr/td[6]/span"));
            String firstSale = first.getText().substring(2);
            System.out.println("Birinci Satış Tutarı=   " + firstSale);
            Thread.sleep(1000);


            //satışa geri dön
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); //üç nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[1]/a")).click(); // satış ekranına git

            // 2.satış yap


            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[2]/div/button[2]")).click();
            Thread.sleep(1000);


            //ÖDEME

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/div[2]/div[2]/button[3]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[3]/div")).click();
            Thread.sleep(3000);

            // Satış Geçmişi


            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); // 3 nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi
            Thread.sleep(4000);

            WebElement second = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/table/tbody/tr/td[6]/span"));
            String secondSale = second.getText().substring(2);
            System.out.println("İkinci Satış Tutarı=    " + secondSale);


            // kasadan para çıkar
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); //üç nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[2]/li[1]/a")).click(); // kasa işlemleri
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul/li[3]/a")).click(); // para çıkar
            Thread.sleep(3000);
            driver.findElement(xpath("//input[@id='close_balance']")).sendKeys("500");// tutar gir

            //   WebElement para = driver.findElement(xpath("//*[@id=\"close_balance\"]"));
            //   String cikanParaString = para.getText();
            //   System.out.println("Kasadan çıkarılan para=" + cikanParaString);

            driver.findElement(xpath("/html/body/div[2]/div/div/div[2]/div/div[2]/div/div[3]/button")).click(); // çıkar
            Thread.sleep(3000);

            //satışa geri dön

            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[1]/a")).click(); // satış ekranına git


            // 3.satış yap


            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[4]/div[1]")).click(); //erkek
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div/div/button[2]")).click(); //ürün
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/div[2]/div[2]/button[3]")).click(); //ödeme
            Thread.sleep(1000);

            //ÖDEME

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[3]/div")).click();
            Thread.sleep(3000);


            // Satış Geçmişi


            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); // 3 nokta
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi
            Thread.sleep(4000);

            WebElement third = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/table/tbody/tr/td[6]/span"));
            String thirdSale = third.getText().substring(2);
            System.out.println("Üçüncü Satış Tutarı=    " + thirdSale);

            //satışa geri dön
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); //üç nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[1]/a")).click(); // satış ekranına git

            // 4.satış yap


            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[2]/div[1]")).click(); //Aydınlatma
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div/div/button[2]")).click();
            Thread.sleep(1000);


            //ÖDEME

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/div[2]/div[2]/button[3]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[3]/div")).click();
            Thread.sleep(3000);

            // Satış Geçmişi


            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); // 3 nokta
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi
            Thread.sleep(4000);

            WebElement fourth = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/table/tbody/tr/td[6]/span"));
            String fourthSale = fourth.getText().substring(2);
            System.out.println("Dördüncü Satış Tutarı=    " + fourthSale);


            // kasaya para ekle
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); // 3 nokta
            Thread.sleep(2000);

            driver.findElement(xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/ul[2]/li[1]/a[1]")).click(); // kasa işlemleri
            Thread.sleep(1000);
            driver.findElement(xpath("//a[contains(text(),'Para Ekle')]")).click(); // para ekle
            Thread.sleep(1000);
            driver.findElement(xpath("//input[@id='close_balance']")).sendKeys("750");// tutar gir

            Thread.sleep(3000);

            driver.findElement(xpath("//button[@class='btn btn-blue btn-wide']")).click(); // ekle

            Thread.sleep(2000);

            //satışa geri dön

            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[1]/a")).click(); // satış ekranına git

            // 5.satış yap

            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[7]")).click(); // giyim
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div/div/button[2]")).click(); //ürün
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/div[2]/div[2]/button[3]")).click();
            Thread.sleep(1000);

            //ÖDEME


            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[3]/div")).click();
            Thread.sleep(3000);

            // Satış Geçmişi


            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); // 3 nokta
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi
            Thread.sleep(4000);

            WebElement fifth = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/table/tbody/tr/td[6]/span"));
            String fifthSale = fifth.getText().substring(2);
            System.out.println("Beşinci Satış Tutarı=   " + fifthSale);


            //TOPLAM SATIŞ


            double toplam;
            double s1 = Double.parseDouble(firstSale);
            double s2 = Double.parseDouble(secondSale);
            double s3 = Double.parseDouble(thirdSale);
            double s4 = Double.parseDouble(fourthSale);
            double s5 = Double.parseDouble(fifthSale);


            toplam = s1 + s2 + s3 + s4 + s5;


            // Kasa kapat
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); // 3 nokta
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[2]/li[1]/a")).click(); // kasa işlemleri
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul/li[4]/a")).click(); // kasayı kapat


            Thread.sleep(3000);
            //toplam tutarı gir


            double total = toplam + 100 - 500 + 750;


            String totalPrice = String.valueOf(total);

            totalPrice = totalPrice.replace(",", "");

            double toplam_int = Double.valueOf(totalPrice.substring(0, totalPrice.length() - 2));

            System.out.println("toplam=" + toplam_int);


            driver.findElement(xpath("//*[@id=\"close_balance\"]")).sendKeys("500");
            Thread.sleep(3000);


            driver.findElement(xpath("/html/body/div[2]/div/div/div[2]/div/div[2]/div/div[4]/button")).click(); //kasayı kapat

            Thread.sleep(3000);

            driver.findElement(xpath("/html/body/div[2]/div/div/button")).click(); //üç nokta
            Thread.sleep(1000);

            driver.findElement(xpath("//div[@class='action']//*[@class='icon']")).click(); //hesaptan çıkış
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div/div[3]/div/div[3]/button[2]")).click(); //eminim -çık


            //login  nesli hesaba gir
            driver.get(loginUrl);
            driver.findElement(name("email")).clear();
            driver.findElement(name("email")).sendKeys("nesli.necipoglu+1@ikas.com");
            Thread.sleep(1000);
            driver.findElement(name("password")).sendKeys("123=ilsen");
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/div/div/div[2]/div/div[2]/form/div[3]/button")).click();
            Thread.sleep(5000);

            driver.findElement(xpath("//li[@class='NavigationLink report']//div[@class='link parent']")).click();  //raporlar
            Thread.sleep(1000);
            driver.findElement(xpath("//a[contains(text(),'Kasa Raporlar')]")).click(); //kasa raporları
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[1]/main/div/div/div[2]/div[2]/div[1]/div/div/div/div[1]/div[2]/div/div")).click();
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div/div[2]/div[2]/div[1]/div/button[2]")).click();
            Thread.sleep(1000);

            // Sistemde Görünen Kasa Durumu

            WebElement x = driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div/div[2]/div[1]/div[3]/p/span/span"));
            String String1 = x.getText();
            System.out.println("Kasa Raporunda Görünen Kasa Durumu = " + String1);


            // Olması Gereken Kasa Durumu

            String String2 = "Kasa Açık Var";

            if (toplam_int > 500) {
                System.out.println(String2);
            } else
                System.out.println("kasa tuttu ya da fazla para var");

            // Sistem doğru çalışıyor mu

            if (String1.equals(String2)) {
                System.out.println("Sistem Doğru");
            } else
                System.out.println("Sistem Yanlış");


            driver.findElement(xpath("/html[1]/body[1]/div[1]/main[1]/div[1]/div[1]/div[1]/div[1]/button[1]")).click(); //kasa rapor görüntüleme çıkış

            Thread.sleep(2000);

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    @Test(priority = 9)
    public void kasaFazlaPara() {

        try {
            test = extent.createTest("Kasada Fazla Para Var");
//logout - nesliden çıkış
            driver.findElement(xpath("/html/body/div[1]/div/div[2]/div/div/button")).click();
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[1]/div/div[2]/div/ul/li[4]/button")).click();
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[1]/div/div[2]/div/div[2]/div/div/div[2]/div[2]/button[2]")).click();
            Thread.sleep(3000);


//login  - seyma sırdag
            driver.get(loginUrl);
            driver.findElement(name("email")).clear();
            driver.findElement(name("email")).sendKeys("nesli.necipoglu+3@ikas.com");
            Thread.sleep(1000);
            driver.findElement(name("password")).sendKeys("1988Nes.");
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/div/div/div[2]/div/div[2]/form/div[3]/button")).click();
            Thread.sleep(5000);

            //POS


            driver.findElement(xpath("/html/body/div[2]/div/div/div[2]/div/button[2]")).click(); // çayyolu
            Thread.sleep(5000);

            // kasa random

            WebElement TerminalTypesContainer = driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div"));
            List<WebElement> TerminalTypes = TerminalTypesContainer.findElements(By.xpath("./*"));
            Random TerminalTypeRandom = new Random();
            int TerminalTypesTypeCount = TerminalTypes.size();
            int TerminalTypesIndex = TerminalTypeRandom.nextInt(TerminalTypesTypeCount);

            WebElement selectedTerminal = TerminalTypes.get(TerminalTypesIndex);
            String className1 = selectedTerminal.getAttribute("class");
            System.out.println(className1);
            selectedTerminal.click();
            Thread.sleep(3000);

            String className = "terminal btn btn-line-white is-open";
            System.out.println(className);
            Thread.sleep(2000);


            if (className1.equals(className)) {

                driver.findElement(xpath("/html/body/div[2]/div/div/div[4]/div/div[3]/button[2]")).click();
            } else {

                driver.findElement(xpath("//*[@id=\"open_balance\"]")).sendKeys("100");

                driver.findElement(xpath("//button[@class='btn btn-blue btn-wide']")).click();
            }


            // 1.satış yap

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[3]/div")).click(); //kadın
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[3]/div/button[2]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/div[2]/div[2]/button[3]")).click();
            Thread.sleep(1000);

            //ÖDEME

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[3]/div")).click();


            // Satış Geçmişi
            Thread.sleep(3000);
            driver.findElement(xpath("//button[@class='btn menu']")).click(); //ÜÇ NOKTA
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi
            Thread.sleep(4000);

            WebElement first = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/table/tbody/tr/td[6]/span"));
            String firstSale = first.getText().substring(2);
            System.out.println("Birinci Satış Tutarı=   " + firstSale);
            Thread.sleep(1000);


            //satışa geri dön
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); //üç nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[1]/a")).click(); // satış ekranına git

            // 2.satış yap


            Thread.sleep(5000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[2]/div/button[2]")).click();
            Thread.sleep(1000);


            //ÖDEME

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/div[2]/div[2]/button[3]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[3]/div")).click();
            Thread.sleep(3000);

            // Satış Geçmişi


            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); // 3 nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi
            Thread.sleep(4000);

            WebElement second = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/table/tbody/tr/td[6]/span"));
            String secondSale = second.getText().substring(2);
            System.out.println("İkinci Satış Tutarı=    " + secondSale);


            // kasadan para çıkar
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); //üç nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[2]/li[1]/a")).click(); // kasa işlemleri
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul/li[3]/a")).click(); // para çıkar
            Thread.sleep(3000);
            driver.findElement(xpath("//input[@id='close_balance']")).sendKeys("500");// tutar gir

            //   WebElement para = driver.findElement(xpath("//*[@id=\"close_balance\"]"));
            //   String cikanParaString = para.getText();
            //   System.out.println("Kasadan çıkarılan para=" + cikanParaString);

            driver.findElement(xpath("/html/body/div[2]/div/div/div[2]/div/div[2]/div/div[3]/button")).click(); // çıkar
            Thread.sleep(3000);

            //satışa geri dön

            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[1]/a")).click(); // satış ekranına git


            // 3.satış yap


            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[4]/div[1]")).click(); //erkek
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div/div/button[2]")).click(); //ürün
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/div[2]/div[2]/button[3]")).click(); //ödeme
            Thread.sleep(1000);

            //ÖDEME

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[3]/div")).click();
            Thread.sleep(3000);


            // Satış Geçmişi


            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); // 3 nokta
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi
            Thread.sleep(4000);

            WebElement third = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/table/tbody/tr/td[6]/span"));
            String thirdSale = third.getText().substring(2);
            System.out.println("Üçüncü Satış Tutarı=    " + thirdSale);

            //satışa geri dön
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); //üç nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[1]/a")).click(); // satış ekranına git

            // 4.satış yap


            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[2]/div[1]")).click(); //Aydınlatma
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div/div/button[2]")).click();
            Thread.sleep(1000);


            //ÖDEME

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/div[2]/div[2]/button[3]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[3]/div")).click();
            Thread.sleep(3000);

            // Satış Geçmişi


            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); // 3 nokta
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi
            Thread.sleep(4000);

            WebElement fourth = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/table/tbody/tr/td[6]/span"));
            String fourthSale = fourth.getText().substring(2);
            System.out.println("Dördüncü Satış Tutarı=    " + fourthSale);


            // kasaya para ekle
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); // 3 nokta
            Thread.sleep(2000);

            driver.findElement(xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/ul[2]/li[1]/a[1]")).click(); // kasa işlemleri
            Thread.sleep(1000);
            driver.findElement(xpath("//a[contains(text(),'Para Ekle')]")).click(); // para ekle
            Thread.sleep(1000);
            driver.findElement(xpath("//input[@id='close_balance']")).sendKeys("750");// tutar gir

            Thread.sleep(3000);

            driver.findElement(xpath("//button[@class='btn btn-blue btn-wide']")).click(); // ekle

            Thread.sleep(2000);

            //satışa geri dön

            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[1]/a")).click(); // satış ekranına git

            // 5.satış yap

            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[7]")).click(); // giyim
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div/div/button[2]")).click(); //ürün
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/div[2]/div[2]/button[3]")).click();
            Thread.sleep(1000);

            //ÖDEME


            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[3]/div")).click();
            Thread.sleep(3000);

            // Satış Geçmişi


            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); // 3 nokta
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi
            Thread.sleep(4000);

            WebElement fifth = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/table/tbody/tr/td[6]/span"));
            String fifthSale = fifth.getText().substring(2);
            System.out.println("Beşinci Satış Tutarı=   " + fifthSale);


            //TOPLAM SATIŞ


            double toplam;
            double s1 = Double.parseDouble(firstSale);
            double s2 = Double.parseDouble(secondSale);
            double s3 = Double.parseDouble(thirdSale);
            double s4 = Double.parseDouble(fourthSale);
            double s5 = Double.parseDouble(fifthSale);


            toplam = s1 + s2 + s3 + s4 + s5;


            // Kasa kapat
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); // 3 nokta
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[2]/li[1]/a")).click(); // kasa işlemleri
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul/li[4]/a")).click(); // kasayı kapat

            //toplam tutarı gir


            double total = toplam + 100 - 500 + 750;


            String totalPrice = String.valueOf(total);

            totalPrice = totalPrice.replace(",", "");

            double toplam_int = Double.valueOf(totalPrice.substring(0, totalPrice.length() - 2));

            System.out.println("toplam=" + toplam_int);


            driver.findElement(xpath("//*[@id=\"close_balance\"]")).sendKeys("3500");
            Thread.sleep(8000);


            driver.findElement(xpath("/html/body/div[2]/div/div/div[2]/div/div[2]/div/div[4]/button")).click(); //kasayı kapat

            Thread.sleep(8000);

            driver.findElement(xpath("/html/body/div[2]/div/div/button")).click(); //üç nokta
            Thread.sleep(1000);


            driver.findElement(xpath("//div[@class='action']//*[@class='icon']")).click(); //hesaptan çıkış
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div/div[3]/div/div[3]/button[2]")).click(); //eminim -çık


            //login
            driver.get(loginUrl);
            driver.findElement(name("email")).clear();
            driver.findElement(name("email")).sendKeys("nesli.necipoglu+1@ikas.com");
            Thread.sleep(1000);
            driver.findElement(name("password")).sendKeys("123=ilsen");
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/div/div/div[2]/div/div[2]/form/div[3]/button")).click();
            Thread.sleep(5000);


            //rapor

            driver.findElement(xpath("//li[@class='NavigationLink report']//div[@class='link parent']")).click();  //raporlar
            driver.findElement(xpath("//a[contains(text(),'Kasa Raporlar')]")).click(); //kasa raporları


            // Sistemde Görünen Kasa Durumu

            Thread.sleep(3000);


            driver.findElement(xpath("/html/body/div[1]/main/div/div/div[2]/div[2]/div[1]/div/div/div/div[1]/div[2]/div/div")).click();

            driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div/div[2]/div[2]/div[1]/div/button[2]")).click();


            WebElement x = driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div/div[2]/div[1]/div[3]/p/span/span"));
            String String1 = x.getText();
            System.out.println("Kasa Raporunda Görünen Kasa Durumu = " + String1);


            // Olması Gereken Kasa Durumu

            String String2 = "Kasa Fazla Verdi";

            if (toplam_int > 500) {
                System.out.println(String2);
            } else
                System.out.println("kasa tuttu ya da açık var");

            // Sistem doğru çalışıyor mu

            if (String1.equals(String2)) {
                System.out.println("Sistem Doğru");
            } else
                System.out.println("Sistem Yanlış");

            driver.findElement(xpath("/html[1]/body[1]/div[1]/main[1]/div[1]/div[1]/div[1]/div[1]/button[1]")).click(); //kasa rapor görüntüleme çıkış
            Thread.sleep(5000);

            //logout - nesliden çıkış
            driver.findElement(xpath("/html/body/div[1]/div/div[2]/div/div/button")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/div/div[2]/div/ul/li[4]/button")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/div/div[2]/div/div[2]/div/div/div[2]/div[2]/button[2]")).click();
            Thread.sleep(1000);


        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test(priority = 10)
    public void kasaTuttu() {

        try {

            test = extent.createTest("Kasa Tuttu");
//login  - seyma sırdag
            driver.get(loginUrl);
            driver.findElement(name("email")).clear();
            driver.findElement(name("email")).sendKeys("nesli.necipoglu+3@ikas.com");
            Thread.sleep(1000);
            driver.findElement(name("password")).sendKeys("1988Nes.");
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/div/div/div[2]/div/div[2]/form/div[3]/button")).click();
            Thread.sleep(5000);

            //POS
            driver.findElement(xpath("/html/body/div[2]/div/div/div[2]/div/button[2]")).click(); // çayyolu
            Thread.sleep(1000);

            //random kasa
            WebElement TerminalTypesContainer = driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div"));
            List<WebElement> TerminalTypes = TerminalTypesContainer.findElements(By.xpath("./*"));
            Random TerminalTypeRandom = new Random();
            int TerminalTypesTypeCount = TerminalTypes.size();
            int TerminalTypesIndex = TerminalTypeRandom.nextInt(TerminalTypesTypeCount);

            WebElement selectedTerminal = TerminalTypes.get(TerminalTypesIndex);
            String className1 = selectedTerminal.getAttribute("class");
            System.out.println(className1);
            selectedTerminal.click();
            Thread.sleep(3000);

            String className = "terminal btn btn-line-white is-open";
            System.out.println(className);
            Thread.sleep(2000);


            if (className1.equals(className)) {

                driver.findElement(xpath("/html/body/div[2]/div/div/div[4]/div/div[3]/button[2]")).click();
            } else {

                driver.findElement(xpath("//*[@id=\"open_balance\"]")).sendKeys("100");

                driver.findElement(xpath("//button[@class='btn btn-blue btn-wide']")).click();
            }


            // 1.satış yap

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[3]/div")).click(); //kadın
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[3]/div/button[2]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/div[2]/div[2]/button[3]")).click();
            Thread.sleep(1000);

            //ÖDEME

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[3]/div")).click();


            // Satış Geçmişi
            Thread.sleep(3000);
            driver.findElement(xpath("//button[@class='btn menu']")).click(); //ÜÇ NOKTA
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi
            Thread.sleep(4000);

            WebElement first = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/table/tbody/tr/td[6]/span"));
            String firstSale = first.getText().substring(2);
            System.out.println("Birinci Satış Tutarı=   " + firstSale);
            Thread.sleep(1000);


            //satışa geri dön
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); //üç nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[1]/a")).click(); // satış ekranına git

            // 2.satış yap


            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[2]/div/button[2]")).click();
            Thread.sleep(1000);


            //ÖDEME

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/div[2]/div[2]/button[3]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[3]/div")).click();
            Thread.sleep(3000);

            // Satış Geçmişi


            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); // 3 nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi
            Thread.sleep(4000);

            WebElement second = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/table/tbody/tr/td[6]/span"));
            String secondSale = second.getText().substring(2);
            System.out.println("İkinci Satış Tutarı=    " + secondSale);

            //para çıkar

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); //üç nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[2]/li[1]/a")).click(); // kasa işlemleri
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul/li[3]/a")).click(); // para çıkar
            Thread.sleep(1000);
            WebElement cikanParaInt = driver.findElement(xpath("//*[@id=\"close_balance\"]"));
            cikanParaInt.sendKeys("500");// tutar gir
            driver.findElement(xpath(" /html/body/div[2]/div/div/div[2]/div/div[2]/div/div[3]/button")).click();  //çıkar

            Thread.sleep(5000);


            //satışa geri dön


            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[1]/a")).click(); // satış ekranına git


            // 3.satış yap


            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[4]/div[1]")).click(); //erkek
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div/div/button[2]")).click(); //ürün
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/div[2]/div[2]/button[3]")).click(); //ödeme
            Thread.sleep(1000);

            //ÖDEME

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[3]/div")).click();
            Thread.sleep(3000);


            // Satış Geçmişi


            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); // 3 nokta
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi
            Thread.sleep(4000);

            WebElement third = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/table/tbody/tr/td[6]/span"));
            String thirdSale = third.getText().substring(2);
            System.out.println("Üçüncü Satış Tutarı=    " + thirdSale);

            //satışa geri dön
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); //üç nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[1]/a")).click(); // satış ekranına git

            // 4.satış yap


            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[2]/div[1]")).click(); //Aydınlatma
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div/div/button[2]")).click();
            Thread.sleep(1000);


            //ÖDEME

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/div[2]/div[2]/button[3]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[3]/div")).click();
            Thread.sleep(3000);

            // Satış Geçmişi


            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); // 3 nokta
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi
            Thread.sleep(4000);

            WebElement fourth = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/table/tbody/tr/td[6]/span"));
            String fourthSale = fourth.getText().substring(2);
            System.out.println("Dördüncü Satış Tutarı=    " + fourthSale);

            //satışa geri dön
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); //üç nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[1]/a")).click(); // satış ekranına git

            // 5.satış yap


            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[7]")).click(); // giyim
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div/div/button[2]")).click(); //ürün
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/div[2]/div[2]/button[3]")).click();
            Thread.sleep(1000);

            //ÖDEME


            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div[3]/div")).click();
            Thread.sleep(3000);

            // Satış Geçmişi


            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); // 3 nokta
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi
            Thread.sleep(4000);

            WebElement fifth = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/table/tbody/tr/td[6]/span"));
            String fifthSale = fifth.getText().substring(2);
            System.out.println("Beşinci Satış Tutarı=   " + fifthSale);


            //TOPLAM SATIŞ


            double toplam;
            double s1 = Double.parseDouble(firstSale);
            double s2 = Double.parseDouble(secondSale);
            double s3 = Double.parseDouble(thirdSale);
            double s4 = Double.parseDouble(fourthSale);
            double s5 = Double.parseDouble(fifthSale);


            toplam = s1 + s2 + s3 + s4 + s5;


            // Kasa kapat
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); // 3 nokta
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[2]/li[1]/a")).click(); // kasa işlemleri
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul/li[4]/a")).click(); // kasayı kapat

            //toplam tutarı gir


            double total = toplam + 100;


            String totalPrice = String.valueOf(total / 10);

            totalPrice = totalPrice.replace(",", "");

            double actualbookfees_amount_int = Double.valueOf(totalPrice.substring(0, totalPrice.length() - 2));

            System.out.println("toplam=" + actualbookfees_amount_int);

            String tp = String.valueOf(actualbookfees_amount_int);


            driver.findElement(xpath("//*[@id=\"close_balance\"]")).sendKeys(tp);
            Thread.sleep(3000);


            driver.findElement(xpath("/html/body/div[2]/div/div/div[2]/div/div[2]/div/div[4]/button")).click(); //kasayı kapat

            Thread.sleep(3000);

            driver.findElement(xpath("/html/body/div[2]/div/div/button")).click(); //üç nokta
            Thread.sleep(1000);

            driver.findElement(xpath("//div[@class='action']//*[@class='icon']")).click(); //hesaptan çıkış
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div/div[3]/div/div[3]/button[2]")).click(); //eminim -çık


            //login
            driver.get(loginUrl);
            driver.findElement(name("email")).clear();
            driver.findElement(name("email")).sendKeys("nesli.necipoglu+1@ikas.com");
            Thread.sleep(1000);
            driver.findElement(name("password")).sendKeys("123=ilsen");
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/div/div/div[2]/div/div[2]/form/div[3]/button")).click();
            Thread.sleep(5000);

            driver.findElement(xpath("//li[@class='NavigationLink report']//div[@class='link parent']")).click();  //raporlar
            driver.findElement(xpath("//a[contains(text(),'Kasa Raporlar')]")).click(); //kasa raporları

            driver.findElement(xpath("/html/body/div[1]/main/div/div/div[2]/div[2]/div[1]/div/div/div/div[1]/div[2]/div/div")).click();

            driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div/div[2]/div[2]/div[1]/div/button[2]")).click();

            driver.findElement(xpath("/html[1]/body[1]/div[1]/main[1]/div[1]/div[1]/div[1]/div[1]/button[1]")).click(); //kasa rapor görüntüleme çıkış

/*


            WebElement beklenenTutar= driver.findElement(xpath("/html/body/div[1]/main/div/div[1]/div/div[2]/div[2]/div[2]/div/table/tbody/tr[2]/td[3]/div[1]/p[2]"));
            String beklenenTutarString= beklenenTutar.getText().substring(2);


            beklenenTutarString = beklenenTutarString.replace(",", "");
            double actualbookfees_amount_intt = Double.valueOf(beklenenTutarString.substring(0, beklenenTutarString.length()-2));
            System.out.println("beklenen=" + actualbookfees_amount_intt);






            if ( beklenenTutarString.equals (tp)) {

                System.out.println("kasa tuttu");
            } else {
                System.out.println("kasa tutmadı");
            }

*/

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    @Test(priority = 11)
    public void ParkaAl() {

        try {
            test = extent.createTest("Parka Al");

            Thread.sleep(5000);
            driver.findElement(xpath("//button[@class='toggle']")).click(); // Yönetici
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[1]/div/div[2]/div/ul/li[2]/a")).click(); // Ayarlar
            Thread.sleep(3000);
            driver.findElement(xpath("/html[1]/body[1]/div[1]/main[1]/div[1]/div[2]/div[1]/div[2]/div[2]/label[5]/span[1]")).click(); // Park Buton Göster
            Thread.sleep(3000);


            WebElement pin = driver.findElement(xpath("/html/body/div[1]/main/div/div[2]/div/div[2]/div[2]/label[10]/div/span"));
            ((JavascriptExecutor) driver).executeScript(
                    "arguments[0].scrollIntoView();", pin);
            Thread.sleep(3000);
            pin.click();


            Thread.sleep(3000);
            driver.findElement(xpath("/html[1]/body[1]/div[1]/main[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[1]/div[2]")).click(); // Değişiklikleri Kaydet
            Thread.sleep(3000);
            driver.findElement(xpath("//a[@class='web btn btn-primary']")).click(); // Pos Ekranına Git
            Thread.sleep(3000);

            driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div/button[2]")).click(); // çayyolu
            Thread.sleep(1000);


            // kasa random

            WebElement TerminalTypesContainer = driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div"));
            List<WebElement> TerminalTypes = TerminalTypesContainer.findElements(By.xpath("./*"));
            Random TerminalTypeRandom = new Random();
            int TerminalTypesTypeCount = TerminalTypes.size();
            int TerminalTypesIndex = TerminalTypeRandom.nextInt(TerminalTypesTypeCount);

            WebElement selectedTerminal = TerminalTypes.get(TerminalTypesIndex);
            String className1 = selectedTerminal.getAttribute("class");
            System.out.println(className1);
            selectedTerminal.click();
            Thread.sleep(3000);

            String className = "terminal btn btn-line-white is-open";
            System.out.println(className);
            Thread.sleep(2000);


            if (className1.equals(className)) {

                driver.findElement(xpath("/html/body/div[2]/div/div/div[4]/div/div[3]/button[2]")).click();
            } else {

                driver.findElement(xpath("//*[@id=\"open_balance\"]")).sendKeys("100");

                driver.findElement(xpath("//button[@class='btn btn-blue btn-wide']")).click();
            }


            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[3]/div/div[1]/div")).click(); //nn
            // pin gir
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[1]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[2]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[3]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[4]")).click();


            // 1.park

            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[4]")).click(); //kadın
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[3]/div/button[2]")).click(); //ürün1
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[4]/div/button[2]")).click();  // ürün2
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div/div[1]/div/button[2]")).click();  // varyant
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div/div[2]/div/button[2]")).click();  // varyant
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[4]/button")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[5]/div/button[2]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div/div/div/div[1]/div[2]/div[1]/div[1]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[4]/button")).click();
            Thread.sleep(2000);
            driver.findElement(xpath(" /html/body/div[2]/div/div/div/div[2]/div/div[1]/button")).click(); // müşteri ekle
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/ul/li[6]")).click();  // müşteri adı
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/div[2]")).click(); // üç nokta
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/ul/li[1]")).click(); //satışı park et
            Thread.sleep(1000);
            driver.findElement(xpath("//*[@id=\"park_note\"]")).sendKeys("Park-1");
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/div[4]/div/div[3]/button[2]")).click(); //park et
            Thread.sleep(3000);

            // 2. park

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[3]")).click(); // Aydınlatma
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[1]/div/button[2]")).click(); //ürün1
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[2]/div/button[2]")).click();  // ürün2
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[3]/div/button[2]")).click();  // ürün3
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[4]/div/button[2]")).click();  // ürün4
            Thread.sleep(2000);
            driver.findElement(xpath(" /html/body/div[2]/div/div/div/div[2]/div/div[1]/button")).click(); // müşteri ekle
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/ul/li[4]")).click();  // müşteri adı
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/div[2]")).click(); // üç nokta
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/ul/li[1]")).click(); //satışı park et
            Thread.sleep(1000);
            driver.findElement(xpath("//*[@id=\"park_note\"]")).sendKeys("Park-2");
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/div[4]/div/div[3]/button[2]")).click(); //park et
            Thread.sleep(3000);

            //Kullanıcı Değiştir

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); //üç nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[3]")).click(); // kilitle
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[4]/div[2]/div[1]/div")).click(); // yeni kullanıcı
            Thread.sleep(1000);
            // pin gir
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[1]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[2]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[3]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[4]")).click();


            // Parka Git
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/button[2]")).click(); // park
            Thread.sleep(2000);
            driver.findElement(xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[1]")).click(); // park-1 seçme
            Thread.sleep(1000);

            // park-1 ürün ekleme

            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[2]")).click(); // ev dekorasyon
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[1]/div/button[2]")).click(); // ürün 1
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[2]/div/button[2]")).click(); // ürün 2
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[3]/div/button[2]")).click(); // ürün 3
            Thread.sleep(1000);

            // tekrar parka al park-1
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/div[2]")).click(); // üç nokta
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/ul/li[1]")).click(); //satışı park et
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/div[4]/div/div[3]/button[2]")).click(); //park et
            Thread.sleep(1000);

            // Parka Git
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/button[2]")).click(); // park
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div/div[2]")).click(); // park-2 seçme
            Thread.sleep(1000);
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[2]")).click(); // ev dekorasyon
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[1]/div/button[2]")).click(); // ürün 1
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[5]")).click(); // erkek
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div/div/button[2]")).click(); // gözlük
            Thread.sleep(1000);

            // tekrar parka al park-2
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/div[2]")).click(); // üç nokta
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/ul/li[1]")).click(); //satışı park et
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/div[4]/div/div[3]/button[2]")).click(); //park et
            Thread.sleep(3000);

            //Kullanıcı Değiştir

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); //üç nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[3]")).click(); // kilitle
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[4]/div[1]/div[1]/div")).click(); // yeni kullanıcı

            // pin gir
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[1]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[2]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[3]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[4]")).click();

            // Parka Git

            // driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[1]/a")).click(); //satış ekranı
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/button[2]")).click(); // park
            Thread.sleep(2000);
            driver.findElement(xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[1]")).click(); // park-1 seçme
            Thread.sleep(1000);

            //parkı öde

            driver.findElement(xpath("//button[@class='paid btn btn-green']")).click(); // ödeme
            Thread.sleep(1000);
            driver.findElement(xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[2]/div[3]/div[1]")).click(); // nakit

            // Parka Git

            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/button[2]")).click(); // park
            Thread.sleep(2000);
            driver.findElement(xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[1]")).click(); // park-1 seçme
            Thread.sleep(1000);

            //parkı öde

            driver.findElement(xpath("//button[@class='paid btn btn-green']")).click(); // ödeme
            Thread.sleep(1000);
            driver.findElement(xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[2]/div[3]/div[1]")).click(); // nakit

            //satış ekranına geri dön
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); //üç nokta
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[2]/li[3]/a")).click();


        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test(priority = 12)
    public void parkKontrol() {

        try {
            test = extent.createTest("Park Kontrol");

            // driver.findElement(xpath("//button[@class='toggle']")).click(); // Yönetici
            //    Thread.sleep(1000);
            // driver.findElement(xpath("/html/body/div[1]/div/div[2]/div/ul/li[2]/a")).click(); // Ayarlar
            //   Thread.sleep(1000);
            // driver.findElement(xpath("/html[1]/body[1]/div[1]/main[1]/div[1]/div[2]/div[1]/div[2]/div[2]/label[5]/span[1]")).click(); // Park Buton Göster
            //  Thread.sleep(1000);
            //  driver.findElement(xpath("/html[1]/body[1]/div[1]/main[1]/div[1]/div[2]/div[1]/div[3]/div[1]")).click(); // Değişiklikleri Kaydet
            Thread.sleep(5000);
            driver.findElement(xpath("//a[@class='web btn btn-primary']")).click(); // Pos Ekranına Git
            Thread.sleep(3000);

            driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div/button[2]")).click(); // çayyolu
            Thread.sleep(1000);
            // random kasa


            WebElement TerminalTypesContainer = driver.findElement(xpath("/html/body/div[2]/div/div/div[3]/div"));
            List<WebElement> TerminalTypes = TerminalTypesContainer.findElements(By.xpath("./*"));
            Random TerminalTypeRandom = new Random();
            int TerminalTypesTypeCount = TerminalTypes.size();
            int TerminalTypesIndex = TerminalTypeRandom.nextInt(TerminalTypesTypeCount);

            WebElement selectedTerminal = TerminalTypes.get(TerminalTypesIndex);
            String className1 = selectedTerminal.getAttribute("class");
            System.out.println(className1);
            selectedTerminal.click();
            Thread.sleep(3000);

            String className = "terminal btn btn-line-white is-open";
            System.out.println(className);
            Thread.sleep(2000);


            if (className1.equals(className)) {

                driver.findElement(xpath("/html/body/div[2]/div/div/div[4]/div/div[3]/button[2]")).click();
            } else {

                driver.findElement(xpath("//*[@id=\"open_balance\"]")).sendKeys("100");

                driver.findElement(xpath("//button[@class='btn btn-blue btn-wide']")).click();
            }


            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[3]/div/div[1]/div")).click();  // kullanıcı

            // pin gir
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[1]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[2]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[3]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[4]")).click();
            Thread.sleep(1000);

            // 2. park

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[3]")).click(); // Aydınlatma
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[1]/div/button[2]")).click(); //ürün1
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[2]/div/button[2]")).click();  // ürün2
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[3]/div/button[2]")).click();  // ürün3
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[4]/div/button[2]")).click();  // ürün4
            Thread.sleep(2000);
            driver.findElement(xpath(" /html/body/div[2]/div/div/div/div[2]/div/div[1]/button")).click(); // müşteri ekle
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/ul/li[4]")).click();  // müşteri adı
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/div[2]")).click(); // üç nokta
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/ul/li[1]")).click(); //satışı park et
            Thread.sleep(1000);
            driver.findElement(xpath("//*[@id=\"park_note\"]")).sendKeys("Park-1");
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/div[4]/div/div[3]/button[2]")).click(); //park et
            Thread.sleep(3000);

            //Kullanıcı Değiştir

            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); //üç nokta
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div[3]")).click(); // kilitle
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[4]/div[2]/div[1]/div")).click(); // yeni kullanıcı
            Thread.sleep(1000);
            // pin gir
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[1]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[2]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[3]")).click();
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div[2]/div/div[5]/div[4]")).click();


            // Parka Git
            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/button[2]")).click(); // park
            Thread.sleep(2000);
            driver.findElement(xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[1]")).click(); // park-1 seçme
            Thread.sleep(1000);

            // park-1 ürün ekleme

            Thread.sleep(3000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[2]")).click(); // ev dekorasyon
            Thread.sleep(2000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[1]/div/button[2]")).click(); // ürün 1
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div[5]")).click(); // erkek
            Thread.sleep(1000);
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div/div/button[2]")).click(); // gözlük
            Thread.sleep(1000);

            //parkı öde
            Thread.sleep(1000);
            driver.findElement(xpath("//button[@class='paid btn btn-green']")).click(); // ödeme
            Thread.sleep(1000);
            driver.findElement(xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[2]/div[3]/div[1]")).click(); // nakit


            Thread.sleep(3000);

            // satış geçmişi
            driver.findElement(xpath("/html/body/div[2]/div/div/div/div[1]/div[1]/button")).click(); // 3 nokta
            Thread.sleep(1000);
            WebElement satisPersonell = driver.findElement(xpath("/html/body/div[2]/div/div/div[4]/div/div[1]/div[1]"));
            String SistendekiSatisPersonelAd = satisPersonell.getText();
            System.out.println(SistendekiSatisPersonelAd);
            Thread.sleep(1000);


            driver.findElement(xpath("/html/body/div[2]/div/div/div[1]/ul[1]/li[3]/a")).click(); // satış geçmişi
            Thread.sleep(2000);
            WebElement satisPersonel = driver.findElement(xpath("/html/body/div[2]/div/div/div/div[2]/div/div[2]/table/tbody/tr[1]/td[7]"));
            String satisPersonelAd = satisPersonel.getText();
            String satisPersonelAdString = satisPersonelAd.toUpperCase();
            System.out.println(satisPersonelAdString);


            //check result

            if (satisPersonelAdString.equals(SistendekiSatisPersonelAd)) {
                System.out.println("Satışı yapan ile Sistemdeki Satış Görevlisi Aynı");

            } else
                System.out.println("Satışı yapan ile Sistemdeki Satış Görevlisi Aynı Değil");


        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    @AfterMethod
    public void getResult(ITestResult result) throws IOException {

        try {
            if (result.getStatus() == ITestResult.FAILURE) {
                test.log(Status.FAIL, MarkupHelper.createLabel(result.getName() + " Test case FAILED" + test.addScreenCaptureFromPath(captureScreen(driver)), ExtentColor.RED));
                test.fail(result.getThrowable());


            } else if (result.getStatus() == ITestResult.SUCCESS) {
                test.log(Status.PASS, MarkupHelper.createLabel(result.getName() + " Test Case PASSED" + test.addScreenCaptureFromPath(captureScreen(driver)), ExtentColor.GREEN));

            } else {
                test.log(Status.SKIP, MarkupHelper.createLabel(result.getName() + " Test Case SKIPPED" + test.addScreenCaptureFromPath(captureScreen(driver)), ExtentColor.ORANGE));
                test.skip(result.getThrowable());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public String captureScreen(WebDriver driver) throws IOException {
        TakesScreenshot screen = (TakesScreenshot) driver;
        File src = screen.getScreenshotAs(OutputType.FILE);
        String dest = "Desktop//Extent Screenshot New //Screenshots//" + getcurrentdateandtime() + ".jpg";
        File target = new File(dest);
        FileUtils.copyFile(src, target);
        return dest;
    }

    public String getcurrentdateandtime() {
        String str = null;

        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy - HH:mm");
        Date date = new Date();
        str = dateFormat.format(date);
        str = str.replace(" ", "").replaceAll("/", "").replaceAll(":", "");

        return str;
    }


    @AfterSuite

    public void tearDown()
    {
        extent.flush();
    }
}




